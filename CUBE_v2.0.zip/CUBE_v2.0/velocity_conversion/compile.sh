gfortran -cpp -fcoarray=single test.f90 ../main/parameters.f90 && ./a.out 
